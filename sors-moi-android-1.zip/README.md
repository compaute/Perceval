# Sors-moi 🐕

Alarme Android pour sortir le chien : toutes les 7 h, des têtes de chien tournoient en plein écran par-dessus tout, avec musique et vibrations, jusqu'au scan du QR code.

## Obtenir l'APK
1. Pousse ce dossier sur GitHub (avec le dossier caché `.github`).
2. Onglet **Actions** : le workflow « Construire l'APK » tourne (environ 5 min).
3. Onglet **Releases** ▸ `latest` ▸ télécharge `sors-moi.apk` depuis le téléphone et installe-le (autorise « sources inconnues »).

Chaque push reconstruit l'APK, et la nouvelle version s'installe par-dessus l'ancienne.
