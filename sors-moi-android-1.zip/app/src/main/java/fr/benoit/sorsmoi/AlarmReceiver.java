package fr.benoit.sorsmoi;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Prefs.setRinging(c, true);
        try {
            c.startForegroundService(new Intent(c, AlarmService.class));
        } catch (Exception e) {
            AlarmService.postFallbackNotification(c);
        }
    }
}
