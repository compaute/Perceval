package fr.benoit.sorsmoi;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;

import java.io.File;
import java.util.Random;

/** Plein de têtes de chien détourées qui volent, rebondissent, tournent et vrillent. */
public class DogStormView extends View {
    private static final int N = 16;

    private final Bitmap dog;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Matrix m = new Matrix();
    private final Random rnd = new Random();
    private final float[] x = new float[N], y = new float[N], vx = new float[N], vy = new float[N];
    private final float[] ang = new float[N], spin = new float[N], size = new float[N], phase = new float[N];
    private final boolean[] flip = new boolean[N];
    private boolean ready;
    private long lastT;

    public DogStormView(Context c) {
        super(c);
        dog = loadSprite(c);
    }

    static Bitmap loadSprite(Context c) {
        File f = new File(c.getFilesDir(), "dog");
        if (f.exists()) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 512) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(f.getPath(), o);
            if (b != null) return b;
        }
        return BitmapFactory.decodeResource(c.getResources(), R.drawable.chien_tete);
    }

    private void setup(int w, int h) {
        float mn = Math.min(w, h);
        for (int i = 0; i < N; i++) {
            size[i] = mn * (0.14f + rnd.nextFloat() * 0.22f);
            x[i] = rnd.nextFloat() * w;
            y[i] = rnd.nextFloat() * h;
            double a = rnd.nextDouble() * Math.PI * 2;
            float sp = mn * (0.35f + rnd.nextFloat() * 0.6f);
            vx[i] = (float) Math.cos(a) * sp;
            vy[i] = (float) Math.sin(a) * sp;
            ang[i] = rnd.nextFloat() * 360f;
            spin[i] = (rnd.nextBoolean() ? 1 : -1) * (120f + rnd.nextFloat() * 480f);
            phase[i] = rnd.nextFloat() * 6.28f;
            flip[i] = rnd.nextInt(3) == 0;
        }
        ready = true;
    }

    private void draw(Canvas c, float cx, float cy, float deg, float px, float squashX) {
        if (dog == null) return;
        float sc = px / Math.max(dog.getWidth(), dog.getHeight());
        m.reset();
        m.postTranslate(-dog.getWidth() / 2f, -dog.getHeight() / 2f);
        m.postScale(sc * squashX, sc);
        m.postRotate(deg);
        m.postTranslate(cx, cy);
        c.drawBitmap(dog, m, paint);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        if (w > 0 && h > 0) setup(w, h);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0 || dog == null) return;
        if (!ready) setup(w, h);
        long now = SystemClock.uptimeMillis();
        float dt = lastT == 0 ? 0.016f : Math.min(0.05f, (now - lastT) / 1000f);
        lastT = now;
        float t = now / 1000f;
        float mn = Math.min(w, h), cx = w / 2f, cy = h / 2f;

        // 1. Têtes qui rebondissent partout en tournant (certaines vrillent comme une pièce)
        for (int i = 0; i < N; i++) {
            x[i] += vx[i] * dt;
            y[i] += vy[i] * dt;
            float r = size[i] / 2f;
            if (x[i] < r) { x[i] = r; vx[i] = Math.abs(vx[i]); }
            if (x[i] > w - r) { x[i] = w - r; vx[i] = -Math.abs(vx[i]); }
            if (y[i] < r) { y[i] = r; vy[i] = Math.abs(vy[i]); }
            if (y[i] > h - r) { y[i] = h - r; vy[i] = -Math.abs(vy[i]); }
            ang[i] += spin[i] * dt;
            float pulse = 1f + 0.25f * (float) Math.sin(t * 4f + phase[i]);
            float squash = flip[i] ? (float) Math.cos(t * 7f + phase[i]) : 1f;
            draw(c, x[i], y[i], ang[i], size[i] * pulse, squash);
        }

        // 2. Tourbillon de têtes en spirale autour du centre
        for (int k = 0; k < 8; k++) {
            float a = t * 2.4f + k * (float) Math.PI / 4f;
            float rad = (0.16f + 0.14f * (float) Math.sin(t * 1.6f + k)) * mn;
            float px = cx + (float) Math.cos(a) * rad;
            float py = cy + (float) Math.sin(a) * rad;
            draw(c, px, py, (float) Math.toDegrees(-a * 2f), mn * 0.17f, 1f);
        }

        // 3. Grosse tête au centre qui vrille et palpite
        float big = mn * 0.55f * (1f + 0.15f * (float) Math.sin(t * 6f));
        draw(c, cx, cy, (t * 260f) % 360f, big, (float) Math.cos(t * 2.5f));

        if (isAttachedToWindow()) postInvalidateOnAnimation();
    }
}
