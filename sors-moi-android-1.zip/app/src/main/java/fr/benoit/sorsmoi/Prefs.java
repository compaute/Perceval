package fr.benoit.sorsmoi;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.SecureRandom;

final class Prefs {
    static final String DEFAULT_TEXT = "CHRIS SORS-MOI !";
    static final String QR_PREFIX = "SORSMOI:";

    private Prefs() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("sorsmoi", Context.MODE_PRIVATE);
    }

    static long next(Context c) { return p(c).getLong("next", 0L); }
    static long last(Context c) { return p(c).getLong("last", 0L); }
    static boolean ringing(Context c) { return p(c).getBoolean("ringing", false); }
    static boolean testing(Context c) { return p(c).getBoolean("testing", false); }
    static boolean silentTest(Context c) { return testing(c) && p(c).getBoolean("silent", false); }
    static void setSilent(Context c, boolean v) { p(c).edit().putBoolean("silent", v).commit(); }
    static String text(Context c) { return p(c).getString("text", DEFAULT_TEXT); }
    static float hours(Context c) { return p(c).getFloat("hours", 7f); }

    static void setNext(Context c, long v) { p(c).edit().putLong("next", v).commit(); }
    static void setLast(Context c, long v) { p(c).edit().putLong("last", v).commit(); }
    static void setRinging(Context c, boolean v) { p(c).edit().putBoolean("ringing", v).commit(); }
    static void setTesting(Context c, boolean v) { p(c).edit().putBoolean("testing", v).commit(); }
    static void setText(Context c, String v) { p(c).edit().putString("text", v).commit(); }
    static void setHours(Context c, float v) { p(c).edit().putFloat("hours", v).commit(); }

    static String secret(Context c) {
        String s = p(c).getString("secret", null);
        return s != null ? s : newSecret(c);
    }

    static String newSecret(Context c) {
        String a = "abcdefghijkmnpqrstuvwxyz23456789";
        SecureRandom r = new SecureRandom();
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 24; i++) b.append(a.charAt(r.nextInt(a.length())));
        String s = b.toString();
        p(c).edit().putString("secret", s).commit();
        return s;
    }

    static String qrContent(Context c) { return QR_PREFIX + secret(c); }
}
