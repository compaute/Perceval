package fr.benoit.sorsmoi;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Les alarmes sont effacées au redémarrage du téléphone : on les remet. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        long now = System.currentTimeMillis();
        long nx = Prefs.next(c);
        if (Prefs.ringing(c) || (nx > 0 && nx <= now)) {
            Scheduler.schedule(c, now + 5_000L);
        } else if (nx > now) {
            Scheduler.schedule(c, nx);
        }
    }
}
