package fr.benoit.sorsmoi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;

import java.util.Collections;

/** Scanner intégré directement dans l'appli (plus d'écran externe qui pouvait fermer l'appli). */
public class ScanActivity extends Activity {
    private static final int REQ_CAM = 5;

    private DecoratedBarcodeView scanner;
    private TextView msg;
    private boolean done;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        svc(AlarmService.ACTION_HIDE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        msg = new TextView(this);
        msg.setTextColor(Color.WHITE);
        msg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        msg.setTypeface(Typeface.DEFAULT_BOLD);
        msg.setGravity(Gravity.CENTER);
        msg.setBackgroundColor(0xAA000000);
        int p = AlarmUi.dp(this, 14);
        msg.setPadding(p, p, p, p);
        msg.setText("Vise le QR code d'arrêt 🐕");

        Button back = new Button(this);
        back.setText("Retour à l'alarme");
        back.setAllCaps(false);
        back.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF3A2C20);
        bg.setCornerRadius(AlarmUi.dp(this, 14));
        back.setBackground(bg);
        back.setOnClickListener(v -> fail());

        try {
            scanner = new DecoratedBarcodeView(this);
            scanner.getBarcodeView().setDecoderFactory(new DefaultDecoderFactory(Collections.singletonList(BarcodeFormat.QR_CODE)));
            scanner.setStatusText("");
            root.addView(scanner, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } catch (Throwable e) {
            scanner = null;
            msg.setText("Impossible d'ouvrir la caméra");
        }

        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        mlp.topMargin = AlarmUi.dp(this, 40);
        root.addView(msg, mlp);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        int m = AlarmUi.dp(this, 20);
        blp.setMargins(m, m, m, AlarmUi.dp(this, 36));
        root.addView(back, blp);

        if (scanner != null) {
            scanner.decodeContinuous(result -> {
                if (done || result == null) return;
                String v = result.getText();
                if (v != null && v.equals(Prefs.qrContent(this))) success();
                else msg.setText("❌ Ce n'est pas le bon QR code");
            });
        }

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (scanner != null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            try { scanner.resume(); } catch (Throwable e) { msg.setText("Impossible d'ouvrir la caméra"); }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (scanner != null) {
            try { scanner.pause(); } catch (Throwable ignored) {}
        }
    }

    /** Si on quitte le scanner sans scanner (bouton accueil…), l'alarme revient tout de suite. */
    @Override
    protected void onStop() {
        super.onStop();
        if (!done && !isChangingConfigurations()) fail();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req != REQ_CAM) return;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            if (scanner != null) {
                try { scanner.resume(); } catch (Throwable ignored) {}
            }
        } else {
            Toast.makeText(this, "Il faut autoriser la caméra pour arrêter l'alarme", Toast.LENGTH_LONG).show();
            fail();
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() { fail(); }

    private void success() {
        done = true;
        boolean test = Prefs.testing(this);
        Prefs.setRinging(this, false);
        stopService(new Intent(this, AlarmService.class));
        if (test) Scheduler.restoreAfterTest(this);
        else Scheduler.markOut(this);
        Toast.makeText(this, test ? "Test réussi !" : "Bonne balade ! 🐾", Toast.LENGTH_LONG).show();
        finish();
    }

    private void fail() {
        if (done) return;
        done = true;
        if (Prefs.ringing(this)) svc(AlarmService.ACTION_SHOW);
        finish();
    }

    private void svc(String action) {
        if (!Prefs.ringing(this)) return;
        try { startService(new Intent(this, AlarmService.class).setAction(action)); } catch (Exception ignored) {}
    }
}
