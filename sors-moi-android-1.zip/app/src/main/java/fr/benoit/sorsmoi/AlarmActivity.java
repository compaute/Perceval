package fr.benoit.sorsmoi;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;

/** Alarme affichée sur l'écran verrouillé. */
public class AlarmActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (!Prefs.ringing(this)) { finish(); return; }
        setContentView(AlarmUi.build(this, v -> scan()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!Prefs.ringing(this)) { finish(); return; }
        // Téléphone déverrouillé : la fenêtre superposée (têtes par-dessus l'écran d'accueil) prend le relais
        KeyguardManager km = getSystemService(KeyguardManager.class);
        boolean locked = km != null && km.isKeyguardLocked();
        if (!locked && Settings.canDrawOverlays(this)) {
            try { startService(new Intent(this, AlarmService.class).setAction(AlarmService.ACTION_SHOW)); } catch (Exception ignored) {}
            finish();
        }
    }

    private void scan() {
        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km != null && km.isKeyguardLocked()) {
            km.requestDismissKeyguard(this, new KeyguardManager.KeyguardDismissCallback() {
                @Override public void onDismissSucceeded() { openScan(); }
            });
        } else {
            openScan();
        }
    }

    private void openScan() {
        startActivity(new Intent(this, ScanActivity.class));
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        // Retour bloqué : seul le QR code arrête l'alarme
    }
}
