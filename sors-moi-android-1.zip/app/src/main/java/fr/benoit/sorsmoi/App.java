package fr.benoit.sorsmoi;

import android.app.Application;
import android.content.Context;

import java.io.PrintWriter;
import java.io.StringWriter;

/** Enregistre la cause d'un plantage pour l'afficher au prochain lancement. */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String s = sw.toString();
                if (s.length() > 3000) s = s.substring(0, 3000);
                getSharedPreferences("crash", MODE_PRIVATE).edit().putString("last", s).commit();
            } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static String lastCrash(Context c) {
        return c.getSharedPreferences("crash", MODE_PRIVATE).getString("last", null);
    }

    static void clearCrash(Context c) {
        c.getSharedPreferences("crash", MODE_PRIVATE).edit().remove("last").commit();
    }
}
