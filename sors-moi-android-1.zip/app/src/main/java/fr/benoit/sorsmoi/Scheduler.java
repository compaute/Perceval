package fr.benoit.sorsmoi;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

final class Scheduler {
    private Scheduler() {}

    private static PendingIntent firePi(Context c) {
        return PendingIntent.getBroadcast(c, 1, new Intent(c, AlarmReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Alarme exacte, réveille le téléphone même appli fermée et en veille profonde. */
    static void schedule(Context c, long at) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent fire = firePi(c);
        am.cancel(fire);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, fire);
            return;
        }
        PendingIntent show = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), fire);
    }

    static void cancel(Context c) {
        c.getSystemService(AlarmManager.class).cancel(firePi(c));
    }

    /** Le chien vient de sortir : on relance le décompte. */
    static void markOut(Context c) {
        long now = System.currentTimeMillis();
        long nx = now + (long) (Prefs.hours(c) * 3600_000L);
        Prefs.setLast(c, now);
        Prefs.setNext(c, nx);
        Prefs.setRinging(c, false);
        Prefs.setTesting(c, false);
        schedule(c, nx);
    }

    static void test(Context c, boolean silent) {
        Prefs.setSilent(c, silent);
        Prefs.setTesting(c, true);
        schedule(c, System.currentTimeMillis() + 10_000L);
    }

    /** Après un test, on remet l'alarme réelle. */
    static void restoreAfterTest(Context c) {
        Prefs.setTesting(c, false);
        long nx = Prefs.next(c), now = System.currentTimeMillis();
        if (nx > now) schedule(c, nx);
        else if (nx > 0) schedule(c, now + 5_000L);
        else cancel(c);
    }
}
