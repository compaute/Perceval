package fr.benoit.sorsmoi;

import android.content.Context;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Petit journal des étapes de l'alarme, affiché dans l'appli pour trouver les bugs. */
final class Journal {
    private static final int MAX = 60;

    private Journal() {}

    static synchronized void add(Context c, String msg) {
        try {
            String line = new SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(new Date()) + "  " + msg;
            Log.i("SorsMoi", line);
            String old = c.getSharedPreferences("journal", Context.MODE_PRIVATE).getString("j", "");
            String[] lines = (line + "\n" + old).split("\n");
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < Math.min(MAX, lines.length); i++) {
                if (lines[i].isEmpty()) continue;
                b.append(lines[i]).append('\n');
            }
            c.getSharedPreferences("journal", Context.MODE_PRIVATE).edit().putString("j", b.toString()).commit();
        } catch (Throwable ignored) {}
    }

    static void err(Context c, String where, Throwable e) {
        add(c, "ERREUR " + where + " : " + e.getClass().getSimpleName() + " " + e.getMessage());
    }

    static String get(Context c) {
        return c.getSharedPreferences("journal", Context.MODE_PRIVATE).getString("j", "");
    }

    static void clear(Context c) {
        c.getSharedPreferences("journal", Context.MODE_PRIVATE).edit().remove("j").commit();
    }
}
