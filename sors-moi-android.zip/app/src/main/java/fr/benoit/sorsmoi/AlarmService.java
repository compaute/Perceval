package fr.benoit.sorsmoi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;

import java.io.File;

/** Fait sonner, vibrer et affiche les têtes par-dessus tout jusqu'au scan du QR code. */
public class AlarmService extends Service {
    static final String CHANNEL = "alarme_v1";
    static final String CHANNEL_FB = "alarme_secours_v1";
    static final String ACTION_HIDE = "fr.benoit.sorsmoi.HIDE";
    static final String ACTION_SHOW = "fr.benoit.sorsmoi.SHOW";
    static final String ACTION_MUTE = "fr.benoit.sorsmoi.MUTE";
    static final long MUTE_MS = 5 * 60_000L;
    static final long SCAN_MS = 90_000L;

    /** Lus par l'écran d'alarme pour afficher le bouton silence. */
    static volatile long muteUntil = 0;
    static volatile boolean muteUsed = false;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable enforcer = new Runnable() {
        @Override public void run() { enforce(); h.postDelayed(this, 1000); }
    };
    private final Runnable reshow = () -> { if (Prefs.ringing(this)) addOverlay(); };

    private boolean started;
    private MediaPlayer mp;
    private View overlay;
    private WindowManager wm;
    private PowerManager.WakeLock wl;
    private int prevVol = -1;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (a == null) {
            if (!started) {
                started = true;
                try {
                    startForeground(1, buildNotification(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
                } catch (Exception e) {
                    postFallbackNotification(this);
                    stopSelf();
                    return START_NOT_STICKY;
                }
                if (!Prefs.ringing(this)) { stopSelf(); return START_NOT_STICKY; }
                muteUntil = 0;
                muteUsed = false;
                wake();
                startSound();
                startVibration();
                addOverlay();
                launchAlarmActivity();
                h.post(enforcer);
            }
            return START_STICKY;
        }
        if (!started) { stopSelf(startId); return START_NOT_STICKY; }
        if (ACTION_HIDE.equals(a)) {
            removeOverlay();
            // Pendant le scan, la fenêtre est cachée 90 s maximum, ensuite elle revient
            h.removeCallbacks(reshow);
            h.postDelayed(reshow, SCAN_MS);
        } else if (ACTION_SHOW.equals(a)) {
            h.removeCallbacks(reshow);
            addOverlay();
        } else if (ACTION_MUTE.equals(a)) {
            mute();
        }
        return START_STICKY;
    }

    // ---------- Notifications ----------
    static Uri alarmUri() {
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        return u;
    }

    static void ensureChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Alarme chien", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setBypassDnd(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);

        NotificationChannel fb = new NotificationChannel(CHANNEL_FB, "Alarme chien (secours)", NotificationManager.IMPORTANCE_HIGH);
        fb.setSound(alarmUri(), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
        fb.enableVibration(true);
        fb.setBypassDnd(true);
        fb.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(fb);
    }

    private static PendingIntent alarmPi(Context c) {
        Intent i = new Intent(c, AlarmActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        return PendingIntent.getActivity(c, 3, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static Notification buildNotification(Context c) {
        ensureChannels(c);
        PendingIntent full = alarmPi(c);
        return new Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(Prefs.text(c))
                .setContentText("Scanne le QR code pour arrêter l'alarme")
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setFullScreenIntent(full, true)
                .setContentIntent(full)
                .build();
    }

    /** Si le service n'a pas pu démarrer : notification qui sonne en boucle. */
    static void postFallbackNotification(Context c) {
        ensureChannels(c);
        PendingIntent full = alarmPi(c);
        Notification n = new Notification.Builder(c, CHANNEL_FB)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(Prefs.text(c))
                .setContentText("C'est l'heure de sortir le chien !")
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setFullScreenIntent(full, true)
                .setContentIntent(full)
                .build();
        n.flags |= Notification.FLAG_INSISTENT;
        try { c.getSystemService(NotificationManager.class).notify(2, n); } catch (Exception ignored) {}
    }

    // ---------- Réveil, son, vibration ----------
    @SuppressWarnings("deprecation")
    private void wake() {
        try {
            PowerManager pm = getSystemService(PowerManager.class);
            wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "sorsmoi:alarme");
            wl.acquire(30 * 60 * 1000L);
        } catch (Exception ignored) {}
    }

    private void startSound() {
        AudioManager am = getSystemService(AudioManager.class);
        try {
            if (prevVol < 0) prevVol = am.getStreamVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        } catch (Exception e) {
            // volume non modifiable
        }
        File f = new File(getFilesDir(), "music");
        if (f.exists() && play(Uri.fromFile(f))) return;
        if (play(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.vite_avant_le_drame))) return;
        play(alarmUri());
    }

    private boolean play(Uri u) {
        if (u == null) return false;
        try {
            releasePlayer();
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            mp.setDataSource(this, u);
            mp.setLooping(true);
            mp.prepare();
            mp.start();
            return true;
        } catch (Exception e) {
            releasePlayer();
            return false;
        }
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) {}
            mp.release();
            mp = null;
        }
    }

    /** Silence une seule fois par alarme, 5 minutes, le temps d'aller au QR code. */
    private void mute() {
        if (muteUsed || mp == null) return;
        muteUsed = true;
        muteUntil = System.currentTimeMillis() + MUTE_MS;
        try { mp.pause(); } catch (Exception ignored) {}
    }

    /** Toutes les secondes : volume remis au max, et le son repart à la fin du silence. */
    private void enforce() {
        long now = System.currentTimeMillis();
        boolean muted = muteUntil > now;
        if (!muted) {
            try {
                AudioManager am = getSystemService(AudioManager.class);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max)
                    am.setStreamVolume(AudioManager.STREAM_ALARM, max, 0);
            } catch (Exception ignored) {}
            if (mp == null) startSound();
            else if (!mp.isPlaying()) { try { mp.start(); } catch (Exception e) { startSound(); } }
        }
    }

    @SuppressWarnings("deprecation")
    private void startVibration() {
        Vibrator v = getSystemService(Vibrator.class);
        if (v == null) return;
        v.vibrate(VibrationEffect.createWaveform(new long[]{0, 900, 400}, 0),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
    }

    // ---------- Fenêtre superposée (par-dessus l'écran d'accueil et les applis) ----------
    @SuppressWarnings("deprecation")
    private void addOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        wm = getSystemService(WindowManager.class);
        View v = AlarmUi.build(this, x -> openScan());
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
                PixelFormat.OPAQUE);
        try {
            wm.addView(v, lp);
            overlay = v;
        } catch (Exception ignored) {}
    }

    private void removeOverlay() {
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) {}
        }
        overlay = null;
    }

    private void openScan() {
        // L'activité est lancée pendant que la fenêtre est encore visible (exigé par Android 15)
        try {
            startActivity(new Intent(this, ScanActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {}
        removeOverlay();
    }

    private void launchAlarmActivity() {
        try {
            startActivity(new Intent(this, AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        muteUntil = 0;
        removeOverlay();
        releasePlayer();
        Vibrator v = getSystemService(Vibrator.class);
        if (v != null) v.cancel();
        if (prevVol >= 0) {
            try { getSystemService(AudioManager.class).setStreamVolume(AudioManager.STREAM_ALARM, prevVol, 0); } catch (Exception ignored) {}
        }
        if (wl != null && wl.isHeld()) wl.release();
        try { getSystemService(NotificationManager.class).cancel(2); } catch (Exception ignored) {}
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
}
