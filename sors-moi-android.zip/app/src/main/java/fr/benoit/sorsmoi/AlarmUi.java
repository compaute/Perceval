package fr.benoit.sorsmoi;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Écran d'alarme partagé par la fenêtre superposée et l'écran verrouillé. */
final class AlarmUi {
    private AlarmUi() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static View build(Context c, View.OnClickListener onScan) {
        FrameLayout root = new FrameLayout(c);
        root.setBackgroundColor(Color.TRANSPARENT);

        root.addView(new DogStormView(c), new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 20);
        col.setPadding(p, dp(c, 48), p, dp(c, 36));
        root.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView t = new TextView(c);
        t.setText(Prefs.text(c));
        t.setAllCaps(true);
        t.setTextColor(0xFFFFD23D);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 48);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setShadowLayer(20, 0, 0, 0xFFFF3D00);
        GradientDrawable tbg = new GradientDrawable();
        tbg.setColor(0xB0000000);
        tbg.setCornerRadius(dp(c, 20));
        t.setBackground(tbg);
        t.setPadding(p, dp(c, 10), p, dp(c, 10));
        col.addView(t, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        View spacer = new View(c);
        col.addView(spacer, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button b = new Button(c);
        b.setText("📷  Scanner le QR code");
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(0xFF1A0F07);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFF8A3D);
        bg.setCornerRadius(dp(c, 18));
        b.setBackground(bg);
        b.setPadding(p, p, p, p);
        b.setOnClickListener(onScan);
        col.addView(b, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Bouton silence : 5 minutes, une seule fois par alarme
        final Button mute = new Button(c);
        mute.setAllCaps(false);
        mute.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        mute.setTypeface(Typeface.DEFAULT_BOLD);
        mute.setTextColor(Color.WHITE);
        GradientDrawable mbg = new GradientDrawable();
        mbg.setColor(0xCC3A2C20);
        mbg.setCornerRadius(dp(c, 16));
        mute.setBackground(mbg);
        mute.setPadding(p, dp(c, 14), p, dp(c, 14));
        mute.setOnClickListener(v -> {
            try { c.startService(new Intent(c, AlarmService.class).setAction(AlarmService.ACTION_MUTE)); } catch (Exception ignored) {}
        });
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = dp(c, 12);
        col.addView(mute, mlp);

        if (Prefs.testing(c)) {
            Button stop = new Button(c);
            stop.setText("⏹  Arrêter le test");
            stop.setAllCaps(false);
            stop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            stop.setTextColor(Color.WHITE);
            GradientDrawable sbg = new GradientDrawable();
            sbg.setColor(0xCC5A1A1A);
            sbg.setCornerRadius(dp(c, 14));
            stop.setBackground(sbg);
            stop.setOnClickListener(v -> AlarmService.stopTest(c));
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            slp.topMargin = dp(c, 12);
            col.addView(stop, slp);
        }

        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable upd = new Runnable() {
            @Override public void run() {
                long left = AlarmService.muteUntil - System.currentTimeMillis();
                if (left > 0) {
                    long s = left / 1000;
                    mute.setText(String.format(java.util.Locale.FRANCE, "🔇  Silence : %d:%02d  (va scanner !)", s / 60, s % 60));
                    mute.setEnabled(false);
                } else if (AlarmService.muteUsed) {
                    mute.setText("🔊  Silence déjà utilisé");
                    mute.setEnabled(false);
                } else {
                    mute.setText("🔇  Couper le son 5 min");
                    mute.setEnabled(true);
                }
                h.postDelayed(this, 500);
            }
        };

        ObjectAnimator pulse = ObjectAnimator.ofPropertyValuesHolder(t,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f),
                PropertyValuesHolder.ofFloat("rotation", -4f, 4f));
        pulse.setDuration(320);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);

        final Animator[] anims = {pulse};
        root.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { for (Animator a : anims) a.start(); h.post(upd); }
            @Override public void onViewDetachedFromWindow(View v) { for (Animator a : anims) a.cancel(); h.removeCallbacks(upd); }
        });
        return root;
    }
}
