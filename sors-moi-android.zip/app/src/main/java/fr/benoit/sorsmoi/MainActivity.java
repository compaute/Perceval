package fr.benoit.sorsmoi;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_IMG = 10, REQ_MUSIC = 11;
    private static final int BG = 0xFF16110D, CARD = 0xFF241B14, TXT = 0xFFF6ECE0, MUT = 0xFFB49C86, ACC = 0xFFFF8A3D;

    private final Handler h = new Handler(Looper.getMainLooper());
    private LinearLayout col, permBox;
    private FrameLayout dogBox;
    private TextView cdLabel, cd, sub, journal;
    private Button outBtn;
    private EditText txt, hrs;
    private ImageView qrView;
    private Bitmap qrBmp;

    private final Runnable tick = new Runnable() {
        @Override public void run() { render(); h.postDelayed(this, 1000); }
    };

    private int dp(float v) { return AlarmUi.dp(this, v); }

    // ---------- Construction de l'écran ----------
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFitsSystemWindows(true);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        col.setPadding(p, dp(20), p, dp(40));
        sv.addView(col);
        setContentView(sv);

        TextView title = text("🐕 Sors-moi  ·  v1.2", 26, TXT, true);
        add(title);

        // Si l'appli a planté, on affiche l'erreur pour pouvoir l'envoyer
        String crash = App.lastCrash(this);
        if (crash != null) {
            LinearLayout cc = card();
            cc.addView(text("💥 L'appli a planté. Fais une capture de ce texte et envoie-la :", 15, 0xFFFFC9A8, true), matchWrap());
            TextView ct = text(crash, 11, MUT, false);
            ct.setTextIsSelectable(true);
            cc.addView(ct, matchWrap());
            Button ok = button("Effacer ce rapport");
            ok.setOnClickListener(v -> { App.clearCrash(this); cc.setVisibility(View.GONE); });
            cc.addView(ok, matchWrap());
            add(cc);
        }

        permBox = card();
        add(permBox);

        LinearLayout dogCard = card();
        dogBox = new FrameLayout(this);
        dogCard.addView(dogBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)));
        add(dogCard);

        LinearLayout cdCard = card();
        cdLabel = text("", 14, MUT, false);
        cd = text("--:--:--", 52, TXT, true);
        cd.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        sub = text("", 15, MUT, false);
        for (TextView t : new TextView[]{cdLabel, cd, sub}) { t.setGravity(Gravity.CENTER); cdCard.addView(t, matchWrap()); }
        add(cdCard);

        outBtn = bigButton("🐾  J'ai sorti le chien");
        outBtn.setOnClickListener(v -> onOut());
        add(outBtn);

        Button testMute = button("🔕  Tester SANS son (dans 10 s : ferme l'appli)");
        testMute.setOnClickListener(v -> startTest(true));
        add(testMute);
        Button test = button("🔔  Tester avec la musique (dans 10 s)");
        test.setOnClickListener(v -> startTest(false));
        add(test);

        // Réglages
        LinearLayout set = card();
        set.addView(text("Réglages", 18, TXT, true), matchWrap());
        set.addView(text("Texte affiché", 14, MUT, false), matchWrap());
        txt = edit(Prefs.text(this), InputType.TYPE_CLASS_TEXT);
        set.addView(txt, matchWrap());
        set.addView(text("Intervalle (heures)", 14, MUT, false), matchWrap());
        hrs = edit(String.valueOf(Prefs.hours(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        set.addView(hrs, matchWrap());
        Button save = button("Enregistrer");
        save.setOnClickListener(v -> saveSettings());
        set.addView(save, matchWrap());
        Button img = button("🖼️  Changer l'image du chien");
        img.setOnClickListener(v -> pick("image/*", REQ_IMG));
        set.addView(img, matchWrap());
        Button mus = button("🎵  Choisir la musique");
        mus.setOnClickListener(v -> pick("audio/*", REQ_MUSIC));
        set.addView(mus, matchWrap());
        Button reset = button("Remettre la tête et la musique de base");
        reset.setOnClickListener(v -> {
            new File(getFilesDir(), "dog").delete();
            new File(getFilesDir(), "music").delete();
            loadDog();
            Toast.makeText(this, "C'est remis par défaut", Toast.LENGTH_SHORT).show();
        });
        set.addView(reset, matchWrap());
        add(set);

        // QR code
        LinearLayout qr = card();
        qr.addView(text("QR code d'arrêt", 18, TXT, true), matchWrap());
        qr.addView(text("Enregistre-le, imprime-le et colle-le près de la laisse. Seul ce QR arrête l'alarme.", 14, MUT, false), matchWrap());
        qrView = new ImageView(this);
        qrView.setBackgroundColor(Color.WHITE);
        qrView.setAdjustViewBounds(true);
        qr.addView(qrView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280)));
        Button saveQr = button("💾  Enregistrer le QR dans la galerie");
        saveQr.setOnClickListener(v -> saveQrToGallery());
        qr.addView(saveQr, matchWrap());
        Button newQr = button("Générer un nouveau QR");
        newQr.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("L'ancien QR imprimé ne marchera plus. Continuer ?")
                .setPositiveButton("Oui", (d, w) -> { Prefs.newSecret(this); renderQr(); })
                .setNegativeButton("Non", null).show());
        qr.addView(newQr, matchWrap());
        add(qr);

        // Journal : à envoyer en capture si quelque chose ne marche pas
        LinearLayout jc = card();
        jc.addView(text("Journal (à m'envoyer en capture en cas de bug)", 16, TXT, true), matchWrap());
        journal = text("", 12, MUT, false);
        journal.setTextIsSelectable(true);
        journal.setTypeface(Typeface.MONOSPACE);
        jc.addView(journal, matchWrap());
        Button jclear = button("Effacer le journal");
        jclear.setOnClickListener(v -> { Journal.clear(this); journal.setText("(vide)"); });
        jc.addView(jclear, matchWrap());
        add(jc);

        renderQr();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPerms();
        loadDog();
        String j = Journal.get(this);
        journal.setText(j.isEmpty() ? "(vide)" : j);
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
        dogBox.removeAllViews();
    }

    // ---------- Petites briques d'interface ----------
    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        return lp;
    }

    private void add(View v) {
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(14);
        col.addView(v, lp);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD, 18));
        int p = dp(16);
        l.setPadding(p, p, p, p);
        return l;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(TXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setBackground(round(0xFF3A2C20, 14));
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        return b;
    }

    private Button bigButton(String s) {
        Button b = button(s);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(0xFF1A0F07);
        b.setBackground(round(ACC, 18));
        b.setPadding(dp(20), dp(22), dp(20), dp(22));
        return b;
    }

    private EditText edit(String v, int type) {
        EditText e = new EditText(this);
        e.setText(v);
        e.setInputType(type);
        e.setTextColor(TXT);
        e.setBackground(round(0xFF1D1611, 12));
        e.setPadding(dp(12), dp(12), dp(12), dp(12));
        return e;
    }

    // ---------- Logique ----------
    private void loadDog() {
        dogBox.removeAllViews();
        dogBox.addView(new DogStormView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(Locale.FRANCE, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
    }

    private void render() {
        long nx = Prefs.next(this), last = Prefs.last(this), now = System.currentTimeMillis();
        SimpleDateFormat f = new SimpleDateFormat("EEEE HH:mm", Locale.FRANCE);
        if (Prefs.ringing(this)) {
            cdLabel.setText("ÇA SONNE !");
            cd.setText("🐕🐕🐕");
            sub.setText("Scanne le QR code pour arrêter.");
            outBtn.setText("📷  Scanner le QR code");
            return;
        }
        outBtn.setText("🐾  J'ai sorti le chien");
        if (nx == 0) {
            cdLabel.setText("PAS ENCORE LANCÉ");
            cd.setText("--:--:--");
            sub.setText("Appuie sur le bouton la première fois que tu sors le chien.");
        } else {
            long r = nx - now;
            cdLabel.setText(r > 0 ? "PROCHAINE SORTIE DANS" : "C'EST L'HEURE !");
            cd.setText(fmt(r));
            String s = "Sonnera " + f.format(new Date(nx));
            if (last > 0) s += "\nDernière sortie : " + f.format(new Date(last));
            if (Prefs.testing(this)) s += "\n(test en cours)";
            sub.setText(s);
        }
    }

    private void startTest(boolean silent) {
        if (Prefs.ringing(this)) return;
        Scheduler.test(this, silent);
        Toast.makeText(this, "Ça sonne dans 10 s" + (silent ? " (sans son)" : "") + ". Ferme l'appli pour voir !", Toast.LENGTH_LONG).show();
    }

    private void onOut() {
        if (Prefs.ringing(this)) {
            startActivity(new Intent(this, ScanActivity.class));
            return;
        }
        long r = Prefs.next(this) - System.currentTimeMillis();
        if (Prefs.next(this) > 0 && r > 30 * 60_000L) {
            new AlertDialog.Builder(this)
                    .setMessage("Relancer le décompte maintenant ?")
                    .setPositiveButton("Oui", (d, w) -> doOut())
                    .setNegativeButton("Non", null).show();
        } else {
            doOut();
        }
    }

    private void doOut() {
        Scheduler.markOut(this);
        Toast.makeText(this, "C'est noté ! 🐾", Toast.LENGTH_SHORT).show();
        render();
    }

    private void saveSettings() {
        String t = txt.getText().toString().trim();
        Prefs.setText(this, t.isEmpty() ? Prefs.DEFAULT_TEXT : t);
        float hv;
        try { hv = Float.parseFloat(hrs.getText().toString().replace(',', '.')); } catch (Exception e) { hv = 7f; }
        if (hv < 0.01f) hv = 0.01f;
        float old = Prefs.hours(this);
        Prefs.setHours(this, hv);
        if (hv != old && Prefs.last(this) > 0 && !Prefs.ringing(this) && !Prefs.testing(this)) {
            long nx = Prefs.last(this) + (long) (hv * 3600_000L);
            Prefs.setNext(this, nx);
            Scheduler.schedule(this, Math.max(nx, System.currentTimeMillis() + 3_000L));
        }
        Toast.makeText(this, "Enregistré", Toast.LENGTH_SHORT).show();
        render();
    }

    @SuppressWarnings("deprecation")
    private void pick(String mime, int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        try { startActivityForResult(i, req); } catch (Exception e) { Toast.makeText(this, "Impossible d'ouvrir le sélecteur", Toast.LENGTH_SHORT).show(); }
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        String name = req == REQ_IMG ? "dog" : req == REQ_MUSIC ? "music" : null;
        if (name == null) return;
        if (copy(data.getData(), new File(getFilesDir(), name))) {
            Toast.makeText(this, req == REQ_IMG ? "Image enregistrée" : "Musique enregistrée", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Échec de l'import", Toast.LENGTH_SHORT).show();
        }
        loadDog();
    }

    private boolean copy(Uri u, File dst) {
        try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(dst)) {
            if (in == null) return false;
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- Permissions ----------
    private void refreshPerms() {
        permBox.removeAllViews();
        permBox.addView(text("⚠️ À autoriser pour que l'alarme marche appli fermée", 15, 0xFFFFC9A8, true), matchWrap());
        int count = 0;
        String pkg = "package:" + getPackageName();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            addPerm("Autoriser les notifications", () -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1));
            count++;
        }
        if (!Settings.canDrawOverlays(this)) {
            addPerm("Afficher par-dessus les autres applis (têtes superposées)",
                    () -> open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse(pkg))));
            count++;
        }
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager.class).canUseFullScreenIntent()) {
            addPerm("Alarme plein écran sur écran verrouillé",
                    () -> open(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse(pkg))));
            count++;
        }
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager.class).canScheduleExactAlarms()) {
            addPerm("Alarmes à l'heure exacte",
                    () -> open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse(pkg))));
            count++;
        }
        PowerManager pm = getSystemService(PowerManager.class);
        if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
            addPerm("Ne pas restreindre la batterie",
                    () -> open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse(pkg))));
            count++;
        }
        permBox.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
    }

    private void addPerm(String label, Runnable r) {
        Button b = button("➜  " + label);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setOnClickListener(v -> r.run());
        permBox.addView(b, matchWrap());
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {}
        }
    }

    // ---------- QR ----------
    private void renderQr() {
        try {
            qrBmp = new BarcodeEncoder().encodeBitmap(Prefs.qrContent(this), BarcodeFormat.QR_CODE, 800, 800);
            qrView.setImageBitmap(qrBmp);
        } catch (Exception e) {
            qrBmp = null;
        }
    }

    private void saveQrToGallery() {
        if (qrBmp == null) return;
        Bitmap page = Bitmap.createBitmap(1000, 1150, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(page);
        c.drawColor(Color.WHITE);
        c.drawBitmap(qrBmp, 100, 40, null);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTextSize(52);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("Scanne-moi pour arrêter l'alarme", 500, 1000, p);
        p.setTextSize(36);
        p.setTypeface(Typeface.DEFAULT);
        c.drawText("Sors-moi 🐕", 500, 1070, p);

        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "sorsmoi-qr-" + System.currentTimeMillis() + ".png");
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SorsMoi");
        try {
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new Exception();
            try (OutputStream o = getContentResolver().openOutputStream(u)) {
                if (o == null) throw new Exception();
                page.compress(Bitmap.CompressFormat.PNG, 100, o);
            }
            Toast.makeText(this, "QR enregistré dans Images > SorsMoi", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Échec de l'enregistrement", Toast.LENGTH_SHORT).show();
        }
    }
}
