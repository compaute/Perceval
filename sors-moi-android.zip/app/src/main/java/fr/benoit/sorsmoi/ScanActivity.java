package fr.benoit.sorsmoi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** Lance le scanner et vérifie que c'est bien le QR code d'arrêt. */
public class ScanActivity extends Activity {
    private static final int REQ_CAM = 5;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        svc(AlarmService.ACTION_HIDE);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
        } else {
            launch();
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req != REQ_CAM) return;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) launch();
        else {
            Toast.makeText(this, "Il faut autoriser la caméra pour arrêter l'alarme", Toast.LENGTH_LONG).show();
            fail();
        }
    }

    private void launch() {
        new IntentIntegrator(this)
                .setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                .setPrompt("Scanne le QR code d'arrêt 🐕")
                .setBeepEnabled(false)
                .setOrientationLocked(false)
                .initiateScan();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        IntentResult r = IntentIntegrator.parseActivityResult(req, res, data);
        if (r == null) return;
        String v = r.getContents();
        if (v != null && v.equals(Prefs.qrContent(this))) {
            success();
        } else {
            if (v != null) Toast.makeText(this, "❌ Ce n'est pas le bon QR code", Toast.LENGTH_LONG).show();
            fail();
        }
    }

    private void success() {
        boolean test = Prefs.testing(this);
        Prefs.setRinging(this, false);
        stopService(new Intent(this, AlarmService.class));
        if (test) Scheduler.restoreAfterTest(this);
        else Scheduler.markOut(this);
        Toast.makeText(this, test ? "Test réussi !" : "Bonne balade ! 🐾", Toast.LENGTH_LONG).show();
        finish();
    }

    private void fail() {
        if (Prefs.ringing(this)) svc(AlarmService.ACTION_SHOW);
        finish();
    }

    private void svc(String action) {
        if (!Prefs.ringing(this)) return;
        try { startService(new Intent(this, AlarmService.class).setAction(action)); } catch (Exception ignored) {}
    }
}
